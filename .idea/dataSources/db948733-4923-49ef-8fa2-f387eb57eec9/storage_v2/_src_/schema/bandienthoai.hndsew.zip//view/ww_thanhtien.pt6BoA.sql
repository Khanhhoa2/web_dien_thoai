create definer = root@localhost view ww_thanhtien as
select `bandienthoai`.`chitietdonhang`.`iddonhang`                                              AS `iddonhang`,
       sum((`bandienthoai`.`chitietdonhang`.`soluong` * `bandienthoai`.`chitietdonhang`.`gia`)) AS `Tongtien`
from `bandienthoai`.`chitietdonhang`
group by `bandienthoai`.`chitietdonhang`.`iddonhang`;

