create definer = root@localhost view vw_spbanchay as
select `bandienthoai`.`chitietdonhang`.`idsanpham`        AS `idsanpham`,
       `bandienthoai`.`chitietsanpham`.`Tensp`            AS `Tensp`,
       `bandienthoai`.`chitietsanpham`.`Hinhanh`          AS `Hinhanh`,
       `bandienthoai`.`chitietdonhang`.`gia`              AS `gia`,
       count(`bandienthoai`.`chitietdonhang`.`idsanpham`) AS `SL`
from (`bandienthoai`.`chitietdonhang`
         join `bandienthoai`.`chitietsanpham`)
where (`bandienthoai`.`chitietdonhang`.`idsanpham` = `bandienthoai`.`chitietsanpham`.`Masanpham`)
group by `bandienthoai`.`chitietdonhang`.`idsanpham`;

